
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define MAX_ROW 10
#define MAX_COL 20
#define MAX_NUM_OF_BOXES 4

typedef enum {END=0, LOSE=1, WIN=2} STATUS;

char map[MAX_ROW][MAX_COL + 2];
char *steps;
int numOfSteps = 0;
int numBox = 0;
int characterPosX = 0, characterPosY = 0;
int boxPosX[MAX_NUM_OF_BOXES];
int boxPosY[MAX_NUM_OF_BOXES];
int goalPosX[MAX_NUM_OF_BOXES + 1];
int goalPosY[MAX_NUM_OF_BOXES + 1];
int x_cur,y_cur;
STATUS gameStatus = END;

FILE *in, *out;

void readFiles(char *filename);
void writeStep(int posX, int posY);
void writeStatus();
void printCurrentMap(char [MAX_ROW][MAX_COL + 2]);
int getCurrentStep(char currentStep);
int copymap[MAX_ROW][MAX_COL + 2];
void move();
void find_wall();
int winn();
int chet();
void checkStatus();
void find_over();
int game_status=0;
void tim_hop();
int main(int argc, char* argv[])
{
    //char *fileInput = "input_lose.txt";
    //char *fileOutput = "output.txt";

    /**
    ** QUAN TRONG: truoc khi submit cac ban comment out 2 dong lenh phia ben tren
    ** va uncomment 2 dong lenh phia ben duoi nhu the nay nhe:
    **      /// char *fileInput = "input.txt";
    **      /// char *fileOutput = "output.txt";
    **
    **      char *fileInput = argv[1];
    **      char *fileOutput = argv[2];
    ** Ban nao khong thuc hien thao tac nay truoc khi submit se bi 0 diem.
    **/

    char *fileInput = argv[1];
     char *fileOutput = argv[2];

    /// read file input
    readFiles(fileInput);
    /// print out the current map to the console
    //printCurrentMap(map);

    /// open file output to write data
    out = fopen(fileOutput, "w");

    /// write the initial position of main character
    int i=0;
    find_over();
    writeStep(y_cur,x_cur);
    for (i = 0; i < numOfSteps; i++)
    {
        /// implement the body part of the program here
        /** TODO: BEGIN **/
        switch (steps[i])
        {
            case '^':
                move(map,&x_cur,&y_cur,1,0,2,0);
                break;
            case 'v':
                move(map,&x_cur,&y_cur,-1,0,-2,0);
                break;
            case '<':
                move(map,&x_cur,&y_cur,0,-1,0,-2);
                break;
            case '>':
                move(map,&x_cur,&y_cur,0,1,0,2);
                break;
            default:
                break;
        }
        tim_hop();
        writeStep(y_cur,x_cur);
        //printCurrentMap(map);
        checkStatus();
        //printf("%d\n",game_status);
        if(game_status!=0) break;
        /** TODO: END **/

        /// exit the loop when reaching WIN status

    }

    /// write status of the game after finishing the steps
    writeStatus();

    /// close file output
    fclose(out);

    return 0;
}

/**
* Print the current map to the console
* You may find this function helpful for debugging
**/
void printCurrentMap(char current_map[MAX_ROW][MAX_COL + 2])
{
    printf("\nCurrent Map:\n");
    int i = 0, j = 0;

    for (i = 0; i < MAX_COL + 2; i++)
    {
        printf(" -");
    }
    printf("\n");

    for (i = 0; i < MAX_ROW; i++)
    {
        printf("%d| ", (MAX_ROW - 1 - i)%10);
        for (j = 0; j < MAX_COL; j++)
        {
            printf("%c ", current_map[MAX_ROW - 1 - i][j]);
        }
        printf("|\n");
    }

    for (i = 0; i < MAX_COL + 2; i++)
    {
        printf(" -");
    }
    printf("\n");

    printf("  ");
    for (i = 0; i < MAX_COL; i++)
    {
        printf(" %d", i%10);
    }
    printf("  ");
    printf("\n");
}

/**
* Read data from file input
**/
void readFiles(char *filename)
{
    int i = 0, j = 0;
    int boxIndex = 0, goalIndex = 0;
    size_t len = 0;
    in = fopen(filename, "r");

    if (in == NULL)
    {
        printf("Unable to open file");
        exit(0);
    }
    char str[300];
    const size_t line_size = 300;
    char* line = malloc(line_size);
    steps=malloc(line_size);
    int row=MAX_ROW;
    while (fgets(line, line_size, in) != NULL)  {
        //printf(line);

        if(row)
        {
            for(i=0;line[i]!=NULL;i++) map[(row-1)][i]=line[i];

        }
        else {
            for(i=0;line[i]!=NULL;i++) steps[i]=line[i];
            numOfSteps = i;
        }
        row--;
    }

    free(line);
    fclose(in);
    i=0,j=0;
    for(i=0;i< MAX_ROW;i++){
        for (j=0;j<MAX_COL;j++){
            if(map[i][j]=='o'){
                boxPosX[numBox]=i;
                boxPosY[numBox]=j;
                numBox++;
            }
        }
    }
    numBox=0;
    i=0,j=0;
    for(i=0;i< MAX_ROW;i++){
        for (j=0;j<MAX_COL;j++){
            if(map[i][j]=='x'){
                goalPosX[numBox]=i;
                goalPosY[numBox]=j;
                numBox++;
                map[i][j]=' ';
            }
        }
    }
    numBox--;
    i=9;
    j=0;
    int min_distance=100000;
    int faker=0;
    for(i=9;i>=0;i--){
        int x=i,y=j;
        int k=0;
        for(k=0;k<=numBox;k++){
            int distance=abs(goalPosX[k]-x)+abs(goalPosY[k]-y);
            //printf("%d %d\n",distance,min_distance);
            if(min_distance > distance){
                min_distance=distance;

                faker=k;
            }
            if(min_distance== distance&&((goalPosX[k]+goalPosY[k])<(goalPosX[faker]+goalPosY[faker]))){
                min_distance=distance;
                faker=k;
            }
        }
        x=i,y=(++j);
         k=0;
        for(k=0;k<=numBox;k++){
            int distance=abs(goalPosX[k]-x)+abs(goalPosY[k]-y);
            if(min_distance >distance){
                min_distance=distance;
                faker=k;
            }
             if(min_distance== distance&&((goalPosX[k]+goalPosY[k])<(goalPosX[faker]+goalPosY[faker]))){
                min_distance=distance;
                faker=k;
            }
        }
        ++j;
    }
    //printf("%d \n",min_distance);
    int h=0;
    int k=0;
    for(k=0;k<numBox;k++){
        if(k==faker) h=1;
        goalPosX[k]=goalPosX[k+h];
        goalPosY[k]=goalPosY[k+h];
    }
    i = 0, j = 0;
    for(i=0;i< MAX_ROW;i++){
        for (j=0;j<MAX_COL;j++){
            if(map[i][j]=='@'){
                x_cur=i;
                y_cur=j;
                return;
            }
        }
    }
}

/**
* Write the position to file output
**/
void writeStep(int posX, int posY)
{
    fprintf(out, "%d:%d\n", posX, posY);
}

/**
* Write final status of the game: WIN, LOSE or END
**/
void writeStatus()
{
    switch(game_status)
    {
        case 1:
            fprintf(out, "WIN\n");
            break;
        case 2:
            fprintf(out, "LOSE\n");
            break;
        default:
            fprintf(out, "END\n");
            break;
    }
}

void move(char current_map[MAX_ROW][MAX_COL + 2],int* x_curr,int* y_curr, int x_plus,int y_plus,int x_plus_two,int y_plus_two){
    int x_new=*x_curr+x_plus;
    int y_new=*y_curr+y_plus;
    if(x_new<0 | x_new >= MAX_ROW | y_new <0 | y_new >=MAX_COL) return;
    if(current_map[x_new][y_new]==' '){
        current_map[x_new][y_new]='@';
        current_map[*x_curr][*y_curr]=' ';
        *x_curr=x_new;
        *y_curr=y_new;
        return;
    }
    if(current_map[x_new][y_new]=='#'){
        return;
    }
    if((*x_curr+x_plus_two)<MAX_ROW&&(*x_curr+x_plus_two)>=0&&(*y_curr+y_plus_two)>=0&&(*y_curr+y_plus_two)<MAX_COL&&(current_map[x_new][y_new]=='o')&&(current_map[*x_curr+x_plus_two][*y_curr+y_plus_two]==' ')){
        current_map[*x_curr+x_plus_two][*y_curr+y_plus_two]='o';
        current_map[x_new][y_new]='@';
        current_map[*x_curr][*y_curr]=' ';
        *x_curr=x_new;
        *y_curr=y_new;
        return;
    }
}
void checkStatus(){
    if(winn(map)!=0){
        game_status=1;
        return;
    }
    if(chet()>0){
        game_status=2;
        return;
    }

}
int winn(char current_map[MAX_ROW][MAX_COL + 2]){

    int i=0;
    for(i=0;i<numBox;i++){
        if(map[goalPosX[i]][goalPosY[i]]!='o'){
            return 0;
        }
    }

    return 1;
}
void find_over(){
    find_wall(copymap);
    int i=0;
    int j=0;
    for(i=0;i<MAX_ROW;i++){
        for(j=0;j<1;j++){
            if(copymap[i][j]==1){
                copymap[i][j]=2;
                break;
            }
        }
        for(j=MAX_COL-1;j>=MAX_COL-1;j--){
            if(copymap[i][j]==1){
                copymap[i][j]=2;
                break;
            }
        }
    }
    for(j=0;j<MAX_COL;j++){
        for(i=0;i<1;i++){
            if(copymap[i][j]==1){
                copymap[i][j]=2;
                break;
            }
        }
        for(i=MAX_ROW-1;i>=MAX_ROW-1;i--){
            if(copymap[i][j]==1){
                copymap[i][j]=2;
                break;
            }
        }
    }


}
int chet(){
    int i=0;
    for(i=0;i<numBox;i++){
        int x=boxPosX[i];
        int y=boxPosY[i];
        if(copymap[x][y]==2){
            if(x==0|x==(MAX_ROW-1)){
                int k2=0;
                int xet=0;
                for(k2=0;k2<numBox;k2++){
                    if(boxPosX[k2]==x){
                        xet++;
                    }
                }
                int xet2=0;
                for(k2=0;k2<numBox;k2++){
                    if(goalPosX[k2]==x){
                        xet2++;
                    }
                }
                if(xet >xet2) return 1;
            }
            if(y==0|y==(MAX_COL-1)){
                int k2=0;
                int xet=0;
                for(k2=0;k2<numBox;k2++){
                    if(boxPosY[k2]==y){
                        xet++;
                    }
                }
                int xet2=0;
                for(k2=0;k2<numBox;k2++){
                    if(goalPosY[k2]==y){
                        xet2++;
                    }
                }
                if(xet >xet2) return 1;
            }
        }
        int hx[]={0,1,0,-1};
        int hy[]={-1,0,1,0};
        int k=0;
        for(k=0;k<numBox;k++){
            if(goalPosX[k]==x&&goalPosY[k]==y) goto D;
        }
        int t=1;
        for(k=0;k<5;k++){
            int x_new=x+hx[k%4];
            int y_new=y+hy[k%4];
            ///printf("%d %d %d \n",x_new,y_new,map[x_new][y_new]);
            if( x_new >=0 &x_new <MAX_ROW& y_new >=0&y_new<MAX_COL&map[x_new][y_new]=='#'){
                    ;
                    if(t==2) return 1;
                    else t=2;
            }
            else {
                t=1;
            }
            //printf("cf %d\n",t);
        }

        D:;
    }
    return 0;
}
void tim_hop(){
    int i=0,j=0,numBox=0;
    for(i=0;i< MAX_ROW;i++){
        for (j=0;j<MAX_COL;j++){
            if(map[i][j]=='o'){
                boxPosX[numBox]=i;
                boxPosY[numBox]=j;
                numBox++;
            }
        }
    }
}
void find_wall(int copymapp[MAX_ROW][MAX_COL + 2])
{
    int check[MAX_ROW][MAX_COL + 2];
    int i=0,j=0;
    for (i=0;i< MAX_ROW;i++){
        for (j=0;j<MAX_COL;j++){
            check[i][j]=0;
        }
    }
    int queue_x[500];
    int queue_y[500];
    int first=0,end=1;
    queue_x[0]=x_cur;
    queue_y[0]=y_cur;
    copymap[x_cur][y_cur]=1;
    while(first < end){
        int x=queue_x[first];
        int y=queue_y[first];
        first++;
        int hx[]={0,1,0,-1};
        int hy[]={-1,0,1,0};
        int k=0;
        for(k=0;k<4;k++){
            int x_new=x+hx[k];
            int y_new=y+hy[k];
            if( x_new >=0 &x_new <MAX_ROW& y_new >=0&y_new<MAX_COL&check[x_new][y_new]==0){
                check[x_new][y_new]=1;
                if(map[x_new][y_new]==' '|map[x_new][y_new]=='@'|map[x_new][y_new]=='o'|map[x_new][y_new]=='x'){
                    copymapp[x_new][y_new]=1;
                    queue_x[end]=x_new;
                    queue_y[end]=y_new;
                    end++;
                }

            }
        }
    }
}





/** TODO: END **/
